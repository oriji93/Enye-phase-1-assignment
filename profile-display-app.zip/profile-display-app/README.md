This project is a simple web application that consumes a rest API to fetch and display profile information of patients.

## How to use this app

Clone a version of this application using the git command - git clone

Navigate to your project folder and run npm install to install all dependencies.


### `How to start the app`
Run npm start or yarn start

This would trigger the application to run your script on localhost

### View your app
Visit your web browser and type - http://localhost:3000
